﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Task_2
{
    class GameEngine
    {
        private Map m = new Map();

        public int count1()
        {
            return m.unitsOnMap.Count;
        }

        public void rules(int i)
        {
            if ((i >= 0) && (i <= m.unitsOnMap.Count) && (m.unitsOnMap[i] != null))
            {
                m.checkHealth();

                #region Building Position Check
                //Check if building on map is no longer there, resets "." to building symbol
                if (m.map[m.buildingsOnMap[0].XPosition, m.buildingsOnMap[0].YPosition] == ".")
                {
                    m.map[m.buildingsOnMap[0].XPosition, m.buildingsOnMap[0].YPosition] = m.buildingsOnMap[0].SymbolImage;
                }
                if (m.map[m.buildingsOnMap[1].XPosition, m.buildingsOnMap[1].YPosition] == ".")
                {
                    m.map[m.buildingsOnMap[1].XPosition, m.buildingsOnMap[1].YPosition] = m.buildingsOnMap[1].SymbolImage;
                }
                #endregion

                //Debug.WriteLine(m.unitsOnMap.Count);
                int currentX = m.unitsOnMap[i].XPosition;
                int currentY = m.unitsOnMap[i].YPosition;

                Debug.WriteLine(i + "kk");
                Debug.WriteLine(m.unitsOnMap[i].SymbolImage);

                Unit closestUnit = m.unitsOnMap[i].nearestUnit(m.unitsOnMap);

                #region Border Check
                if (m.unitsOnMap[i].FactionTeam == "Red")
                {
                    if (m.unitsOnMap[i].XPosition == 0)
                    {
                        m.map[m.unitsOnMap[i].XPosition, m.unitsOnMap[i].YPosition] = ".";
                        m.unitsOnMap.Remove(m.unitsOnMap[i]);
                        Debug.WriteLine("Deleted1");
                    }
                    Debug.WriteLine("TRUE3");
                    m.unitMove(m.unitsOnMap[i], currentX - 1, currentY);
                }
                else
                {
                    if (m.unitsOnMap[i].XPosition == 19)
                    {
                        m.map[m.unitsOnMap[i].XPosition, m.unitsOnMap[i].YPosition] = ".";
                        m.unitsOnMap.Remove(m.unitsOnMap[i]);
                        Debug.WriteLine("Deleted2");
                    }
                    //.WriteLine("TRUE4");
                    m.unitMove(m.unitsOnMap[i], currentX + 1, currentY);
                }
                #endregion

                #region Basic Movement
                Debug.WriteLine("TRUE2 Kruben");
                if (closestUnit != null)
                {
                    if (m.unitsOnMap[i].XPosition < closestUnit.XPosition)
                    {
                        m.unitMove(m.unitsOnMap[i], currentX + 1, currentY);
                        Debug.WriteLine("moved 1");
                    }
                    if (m.unitsOnMap[i].XPosition > closestUnit.XPosition)
                    {
                        m.unitMove(m.unitsOnMap[i], currentX - 1, currentY);
                        Debug.WriteLine("moved 2");
                    }

                    if (m.unitsOnMap[i].YPosition < closestUnit.YPosition)
                    {
                        m.unitMove(m.unitsOnMap[i], currentX, currentY + 1);
                        Debug.WriteLine("moved 3");
                    }
                    if (m.unitsOnMap[i].YPosition > closestUnit.YPosition)
                    {
                        m.unitMove(m.unitsOnMap[i], currentX, currentY - 1);
                        Debug.WriteLine("moved 4");
                    }
                }
                #endregion

                #region Combat
                if (closestUnit != null)
                {
                    if (m.unitsOnMap[i].isEnemyInRange(closestUnit))
                    {
                        m.unitsOnMap[i].combat(closestUnit);
                        //closestUnit = m.unitsOnMap[i].nearestUnit(m.unitsOnMap);
                    }
                    if (m.unitsOnMap[i].Health < 25)
                    {
                        m.unitsOnMap[i].move(m.unitsOnMap[i].XPosition, m.unitsOnMap[i].YPosition);
                    }
                }
                #endregion

            }

        }

        #region Map Methods
        public void GEinitialiseMap()
        {
            m.initialiseMap();
        }

        public void GEbattlefield()
        {
            m.battlefield();
        }

        public string GEredraw()
        {
            return m.redraw();
        }

        public void GEconstructBuildings()
        {
            m.constructBuildings();
        }

        public void GEsave()
        {
            m.save();
        }

        public void GEread()
        {
            m.readMeleeUnit();
            m.readRangedUnit();
            m.readResourceBuilding();
            m.readFactoryBuilding();
        }

        public int GElistUnitsOnMapCount()
        {
            return m.unitsOnMap.Count;
        }

        public string GEtoString(int i)
        {

            return m.unitsOnMap[i].toString();

        }
        #endregion*/
    }
}
